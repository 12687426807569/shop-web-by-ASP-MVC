﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting.Internal;
using myShop.Models;
using myShop.ViewModels;
using System.IO;
using System.Security.Claims;

namespace myShop.Controllers
{
    public class ProductController : Controller
    {
        private readonly ILogger<ProductController> _logger;
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public ProductController(ILogger<ProductController> logger, AppDbContext context, IWebHostEnvironment env)
        {
            _logger = logger;
            _context = context;
            _env = env;
        }

        public IActionResult Index()
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            var id=HttpContext.Session.GetInt32("UserId");
            var userWithProducts = _context.Users.Where(u => u.Id == id && !u.IsDeleted)
                .Select(u => new User
                {
                    Id = u.Id,
                    Name = u.Name,
                    Products = u.Products
                    .Where(p => !p.IsDeleted).ToList()
                }).FirstOrDefault();

            if (userWithProducts == null)
            {
                return NotFound();
            }

            return View(userWithProducts);
        }
        [HttpPost]
        public IActionResult Index(int id)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            var product = _context.Products.Find(id);
            if (product == null) return NotFound();

            product.IsDeleted = true;
            _context.SaveChanges();
            return RedirectToAction("index");
        }
        public IActionResult Create()
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            return View(new ProductCreateViewModel());
        }
        [HttpPost]
        public IActionResult Create(ProductCreateViewModel updatedProduct)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            /*if (updatedProduct.Image == null)
            {
                ModelState.AddModelError("Image", "請上傳商品圖片");
                return View(updatedProduct);
            }*/
            string fileName = Guid.NewGuid().ToString() + "_" + updatedProduct.Image.FileName;
            string uploadsFolder = Path.Combine(_env.WebRootPath, "images");
            var filePath = Path.Combine(uploadsFolder, fileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                updatedProduct.Image.CopyTo(stream);
            }
            _context.Products.Add(new Product
            {
                Name = updatedProduct.Name,
                Description = updatedProduct.Description,
                Price = updatedProduct.Price,
                Stock = updatedProduct.Stock,
                ImageUrl = fileName,
                SellerId = HttpContext.Session.GetInt32("UserId").GetValueOrDefault(),
            });
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            var product = _context.Products.FirstOrDefault
                (p => p.Id == id && !p.IsDeleted);
            if (product == null) return NotFound();

            return View(new ProductEditViewModel
            {
                Id = product.Id,
                Name = product.Name,
                Description = product.Description,
                Price = product.Price,
                Stock = product.Stock,
                ExistingUrl = product.ImageUrl
            });
        }
        [HttpPost]
        public IActionResult Edit(ProductEditViewModel updatedProduct)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");

            if (updatedProduct.Image == null)
            {
                ModelState.AddModelError("Image", "請上傳商品圖片");
                return View(updatedProduct);
            }
            var product = _context.Products.FirstOrDefault(p =>
            p.Id == updatedProduct.Id && !p.IsDeleted);
            if (product == null) return NotFound();

            product.Name = updatedProduct.Name;
            product.Description = updatedProduct.Description;
            product.Price = updatedProduct.Price;
            product.Stock = updatedProduct.Stock;

            if(updatedProduct.ExistingUrl!= null&&updatedProduct.ExistingUrl!= "default.png")
            {
                System.IO.File.Delete(Path.Combine(_env.WebRootPath, "images", updatedProduct.ExistingUrl));
            }

            string fileName = Guid.NewGuid().ToString() + "_" + updatedProduct.Image.FileName;
            string uploadsFolder = Path.Combine(_env.WebRootPath, "images");
            var filePath = Path.Combine(uploadsFolder, fileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                updatedProduct.Image.CopyTo(stream);
            }


            product.ImageUrl = fileName;
            _context.SaveChanges();
            

            return RedirectToAction("Index");
        }
    }
}
