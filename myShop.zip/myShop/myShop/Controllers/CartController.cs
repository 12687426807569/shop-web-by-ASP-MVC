﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using myShop.Models;
using System.Security.AccessControl;

namespace myShop.Controllers
{
    public class CartController : Controller
    {
        private readonly ILogger<CartController> _logger;
        private readonly AppDbContext _context;

        public CartController(ILogger<CartController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }
        public IActionResult Index(int? productId)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            if (productId==null)
                return View();
            if (productId == 0)
            {
                HttpContext.Session.Remove("ProductId");
                return View();
            }
            var product = _context.Products.FirstOrDefault
                (p => p.Id == productId && !p.IsDeleted);
            if (product == null)
                return BadRequest("商品不存在或數量錯誤");

            HttpContext.Session.SetInt32("ProductId", productId??0);
            ViewBag.quantity = 1;

            return View(product);
        }
        [HttpPost]
        public async Task<IActionResult> Index(int quantity)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            var product = _context.Products.FirstOrDefault
                (p => p.Id == HttpContext.Session.GetInt32("ProductId") && !p.IsDeleted);
            if (product==null||product.Stock < quantity)
                return BadRequest("庫存不足");

            var userId = HttpContext.Session.GetInt32("UserId");
            var order = new Order
            {
                BuyerId = userId ?? 0,
                SellerId = product.SellerId,
                Quantity = quantity,
                NowName = product.Name,
                NowDescription = product.Description,
                NowPrice = product.Price,
                NowImageUrl=product.ImageUrl,
                Status =OrderStatus.Created,
                CreatedAt = DateTime.Now
            };
        

            product.Stock -= quantity;

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();


            HttpContext.Session.SetInt32("ProductId",  0);
            return View();
        }
    }
}
