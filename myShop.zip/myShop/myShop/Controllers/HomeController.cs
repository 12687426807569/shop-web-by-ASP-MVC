using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using myShop.Models;
using System.Diagnostics;

namespace myShop.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            var products = _context.Products.ToList();
            return View(products);
        }
        [HttpGet]
        public IActionResult LoginRegister()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = _context.Users.FirstOrDefault
                (u => u.Email == email && u.Password == password && !u.IsDeleted);
            if (user != null)
            {
                HttpContext.Session.SetInt32("UserId", user.Id);
                HttpContext.Session.SetString("UserName", user.Name);

                return RedirectToAction("Index");
            }

            ViewBag.LoginError = "�o�����s";
            return View("LoginRegister");
        }
        [HttpPost]
        public async Task<IActionResult> Register(User user)
        {
            if (_context.Users.Any(u => u.Email == user.Email&& !u.IsDeleted))
            {
                ViewBag.RegisterError = "Email �ߔ풐��";
                return View("LoginRegister");
            }

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            HttpContext.Session.SetInt32("UserId", user.Id);
            HttpContext.Session.SetString("UserName", user.Name);
            return RedirectToAction("Index");
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("LoginRegister");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
