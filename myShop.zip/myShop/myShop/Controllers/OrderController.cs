﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using myShop.Models;
using System.Security.Claims;

namespace myShop.Controllers
{
    public class OrderController : Controller
    {
        private readonly ILogger<OrderController> _logger;
        private readonly AppDbContext _context;

        public OrderController(ILogger<OrderController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }
        public IActionResult SellOrders()
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            int sellerId = HttpContext.Session.GetInt32("UserId") ?? 0;

             var user = _context.Users.Where(u => u.Id == sellerId && !u.IsDeleted)
                .Include(u => u.SellOrders).ThenInclude(o => o.Buyer).FirstOrDefault();

            if (user != null)
            {
                user.SellOrders = user.SellOrders
                    .Where(o => !o.IsDeleted)
                    .ToList();
            }
            return View(user);
        }
        [HttpPost]
        public   async Task<IActionResult> SellOrders(int id)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            var order = await _context.Orders.FindAsync(id);
            if (order == null || order.Status != OrderStatus.Created||order.IsDeleted)
            {
                return NotFound();
            }

            order.Status = OrderStatus.Shipped;
            await _context.SaveChangesAsync();

            return RedirectToAction("SellOrders");
        }
        public IActionResult BuyOrders()
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            int buyerId = HttpContext.Session.GetInt32("UserId") ?? 0;

            var user = _context.Users.Where(u => u.Id == buyerId && !u.IsDeleted)
               .Include(u => u.BuyOrders).ThenInclude(o => o.Seller).FirstOrDefault();

            if (user != null)
            {
                user.BuyOrders = user.BuyOrders
                    .Where(o => !o.IsDeleted)
                    .ToList();
            }
            return View(user);
        }
        [HttpPost]
        public IActionResult BuyOrders(int id)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            var order =  _context.Orders.Find(id);
            if (order == null || order.Status != OrderStatus.Shipped || order.IsDeleted)
            {
                return NotFound();
            }

            order.Status = OrderStatus.Received;
             _context.SaveChanges();

            return RedirectToAction("BuyOrders");
        }
    }
}
