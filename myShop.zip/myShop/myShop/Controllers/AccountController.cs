﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using myShop.Models;
using myShop.ViewModels;

namespace myShop.Controllers
{
    public class AccountController : Controller
    {
        private readonly ILogger<AccountController> _logger;
        private readonly AppDbContext _context;

        public AccountController(ILogger<AccountController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }
        public ActionResult Index()
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");
            var userId =HttpContext.Session.GetInt32("UserId");
            var user = _context.Users.FirstOrDefault(u => u.Id == userId && !u.IsDeleted);

            if (user == null) 
                return NotFound();

            var vm = new AccountIndexViewModel { Name = user.Name };
            ViewBag.Email = user.Email;
            return View(vm);
        }
        [HttpPost]
        public ActionResult Index(AccountIndexViewModel vm)
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
                return RedirectToAction("LoginRegister");

            if (!ModelState.IsValid) 
                return View(vm);

            var userId = HttpContext.Session.GetInt32("UserId");
            var user = _context.Users.FirstOrDefault(u=>u.Id==userId&&!u.IsDeleted);
            if (user == null) return NotFound();

            if (user.Password != vm.CurrentPassword)
            {
                ModelState.AddModelError("CurrentPassword", "原密碼錯誤");
                return View(vm);
            }

            user.Name = vm.Name;
            if (!string.IsNullOrWhiteSpace(vm.NewPassword))
                user.Password = vm.NewPassword;

            _context.SaveChanges();
            ViewBag.Success = true;
            return View(vm);
        }
    }
}
