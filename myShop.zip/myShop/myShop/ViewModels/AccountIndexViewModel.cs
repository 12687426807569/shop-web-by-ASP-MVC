﻿using System.ComponentModel.DataAnnotations;

namespace myShop.ViewModels
{
    public class AccountIndexViewModel
    {
        [Required]
        public string Name { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string CurrentPassword { get; set; }

        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "新密碼與確認密碼不一致")]
        public string ConfirmPassword { get; set; }
    }
}
