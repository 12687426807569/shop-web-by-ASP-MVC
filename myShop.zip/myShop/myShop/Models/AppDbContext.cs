﻿using Microsoft.EntityFrameworkCore;

namespace myShop.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options)
        {
        }
        // 三個 DbSet 對應三個資料表
        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // User 與 Product 一對多 (一個 User 可有多個 Product)
            modelBuilder.Entity<User>()
                .HasMany(u => u.Products)
                .WithOne()
                .HasForeignKey(p => p.SellerId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<User>()
                .HasMany(u => u.BuyOrders)
                .WithOne(o =>o.Buyer)
                .HasForeignKey(o => o.BuyerId)
                .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<User>()
                .HasMany(u => u.SellOrders)
                .WithOne(o => o.Seller)
                .HasForeignKey(o => o.SellerId)
                .OnDelete(DeleteBehavior.Restrict);

            // Product 與 Order 一對多 (一個 Product 可有多筆訂單)
            /* modelBuilder.Entity<Product>()
                 .HasMany<Order>()
                 .WithOne()
                 .HasForeignKey(o => o.ProductId)
                 .OnDelete(DeleteBehavior.Restrict);*/

            // Enum 轉換成 int 存資料庫（EF Core 預設行為，這裡寫出來更清楚）
            modelBuilder.Entity<Order>()
                .Property(o => o.Status)
                .HasConversion<int>();
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    Id = 1,
                    Name = "測試商品1",
                    Description = "這是測試用的商品1",
                    Price = 100,
                    Stock = 10,
                    SellerId = 1,
                    ImageUrl = "default.png"
                }, new Product
                {
                    Id = 2,
                    Name = "測試商品2",
                    Description = "這是測試用的商品2",
                    Price = 200,
                    Stock = 20,
                    SellerId = 1,
                    ImageUrl = "default.png"
                }
                ); 
            modelBuilder.Entity<User>().HasData(
                new User { 
                    Id = 1,
                    Name = "測試用戶1",
                    Email = "seller@example.com",
                    Password = "123456" 
                }, new User
                {
                    Id = 2,
                    Name = "123",
                    Email = "a0979086822@gmail.com",
                    Password = "123"
                }
                );
            /*modelBuilder.Entity<Order>().HasData(
                new Order
                {
                    Id = 1,
                    BuyerId = 2,
                    SellerId = 1,
                    Quantity = 1,
                    NowName = "測試商品1",
                    NowDescription = "這是測試用的商品1",
                    NowPrice = 100,
                    NowImageUrl = "default.png",
                    Status = OrderStatus.Created,
                    CreatedAt = DateTime.Now
                }, new Order
                {
                    Id = 2,
                    BuyerId = 2,
                    SellerId = 1,
                    Quantity = 2,
                    NowName = "測試商品2",
                    NowDescription = "這是測試用的商品2",
                    NowPrice = 200,
                    NowImageUrl = "default.png",
                    Status = OrderStatus.Shipped,
                    CreatedAt = DateTime.Now
                }
            );*/
        }
    }
}



