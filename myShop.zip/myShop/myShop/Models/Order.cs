﻿
namespace myShop.Models
{
    public enum OrderStatus
    {
        Created = 1, // 訂單成立，尚未出貨
        Shipped = 2, // 已出貨，未收到
        Received = 3  // 已收到
    }
    public class Order
    {
        public int Id { get; set; }
        public bool IsDeleted { get; set; }
        public int BuyerId { get; set; }
        public User Buyer { get; set; }
        public int SellerId { get; set; }
        public User Seller { get; set; }
        public int Quantity { get; set; }
        public string NowName { get; set; }
        public string NowDescription { get; set; }
        public decimal NowPrice { get; set; }
        public string NowImageUrl { get; set; } = "default.png";
        public OrderStatus Status { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
