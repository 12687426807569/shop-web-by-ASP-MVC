﻿namespace myShop.Models
{
    public class User
    {
        public int Id { get; set; }
        public bool IsDeleted { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public ICollection<Product> Products { get; set; }
        public ICollection<Order> BuyOrders { get; set; }
        public ICollection<Order> SellOrders { get; set; }
    }
}
